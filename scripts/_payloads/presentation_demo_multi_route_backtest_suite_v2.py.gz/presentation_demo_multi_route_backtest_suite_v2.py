#!/usr/bin/env python3
"""Presentation/demo multi-route backtest suite v2.1.

Extends the v1 presentation-only suite without reopening the frozen competition
science. v2 fixes Kalshi live-vs-historical candlestick routing and materializes
ForecastEx from the official daily CSV archive using actual Yes/No contract
prices rather than assuming complementarity.
"""
from __future__ import annotations

import base64
import bisect
import csv
import gzip
import io
import json
import os
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any

REPO = "pablo-marchina/desafio-quant"
V1_BLOB_SHA = "24bd79ab3c79f0b1fe590e637f0e2261f8443da1"
ROOT = Path(__file__).resolve().parents[1]
REGISTRY = ROOT / "registry"
KALSHI_BASE = os.getenv("ARGOS_KALSHI_BASE", "https://external-api.kalshi.com/trade-api/v2").rstrip("/")
FORECASTEX_BASE = os.getenv("ARGOS_FORECASTEX_BASE", "https://forecastex.com").rstrip("/")
MAX_KALSHI = int(os.getenv("ARGOS_MULTI_KALSHI_MARKETS", "80"))
MAX_KALSHI_PAGES = int(os.getenv("ARGOS_MULTI_KALSHI_PAGES_PER_TIER", "6"))
MAX_FORECASTEX = int(os.getenv("ARGOS_MULTI_FORECASTEX_CONTRACTS", "120"))
FORECASTEX_WORKERS = int(os.getenv("ARGOS_MULTI_FORECASTEX_WORKERS", "8"))
FORECASTEX_FEE = float(os.getenv("ARGOS_MULTI_FORECASTEX_FEE_PER_CONTRACT", "0.01"))


def _fetch_v1_source() -> str:
    url = f"https://api.github.com/repos/{REPO}/git/blobs/{V1_BLOB_SHA}"
    req = urllib.request.Request(url, headers={"User-Agent": "ARGOS-multi-route-v2/2.0"})
    with urllib.request.urlopen(req, timeout=30) as resp:
        payload = json.loads(resp.read().decode("utf-8"))
    src = base64.b64decode(payload["content"]).decode("utf-8")
    replacements = {
        "presentation_demo_multi_route_backtest_summary_v1.json": "presentation_demo_multi_route_backtest_summary_v2.json",
        "presentation_demo_multi_route_backtest_scorecard_v1.csv": "presentation_demo_multi_route_backtest_scorecard_v2.csv",
        "presentation_demo_multi_route_backtest_trades_v1.csv": "presentation_demo_multi_route_backtest_trades_v2.csv",
        "presentation_demo_multi_route_backtest_funnels_v1.csv": "presentation_demo_multi_route_backtest_funnels_v2.csv",
        "presentation_demo_multi_route_legacy_equity_baseline_v1.json": "presentation_demo_multi_route_legacy_equity_baseline_v2.json",
        "presentation_demo_multi_route_forecastex_blocker_v1.json": "presentation_demo_multi_route_forecastex_backtest_v2.json",
        '"forecastex_blocker": rel(FORECASTEX_OUT)': '"forecastex_route": rel(FORECASTEX_OUT)',
        '"version": "v1",': '"version": "v2",',
        "s, f = materialize_forecastex()\n        all_summaries.append(s); all_funnels.extend(f)": "s, t, f = materialize_forecastex()\n        all_summaries.append(s); all_trades.extend(t); all_funnels.extend(f)",
    }
    for old, new in replacements.items():
        if old not in src:
            raise RuntimeError(f"v2_controlled_patch_missing:{old}")
        src = src.replace(old, new, 1)
    return src


SRC = _fetch_v1_source()
NS: dict[str, Any] = {"__name__": "argos_multi_route_v1_base", "__file__": str(ROOT / "scripts" / ".v1_blob.py")}
exec(compile(SRC, NS["__file__"], "exec"), NS, NS)

# Preserve extra provenance fields across all route CSV rows.
NS["TRADE_FIELDS"] = list(NS["TRADE_FIELDS"]) + [
    "entry_no_price", "terminal_no_price", "data_tier", "price_source", "entry_archive_date"
]


def _iso_ts(v: Any) -> int | None:
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return int(v)
    s = str(v).strip()
    if not s:
        return None
    try:
        return int(datetime.fromisoformat(s.replace("Z", "+00:00")).timestamp())
    except Exception:
        return NS["parse_ts"](v)


def _unit_price(v: Any) -> float | None:
    x = NS["fnum"](v)
    if x is None:
        return None
    if 1 < x <= 100:
        x /= 100.0
    return float(x) if 0 <= x <= 1 else None


# ---------------------------------------------------------------------------
# Kalshi v2.1: reuse the already-audited W4-B universe instead of ranking the
# raw settled-market feed (which over-selected MVE / multi-game contracts).
# Candidate selection uses only pre-existing availability/semantic metadata,
# never price, settlement, or PnL.
# ---------------------------------------------------------------------------

W4B_KALSHI_MARKET = REGISTRY / "w4b_kalshi_history_market_v1_0_3.csv.gz"
W4B_KALSHI_EVENT = REGISTRY / "w4b_kalshi_history_event_v1_0_3.csv.gz"


def _kalshi_cutoff() -> tuple[int | None, str | None]:
    try:
        data = NS["http_json"](f"{KALSHI_BASE}/historical/cutoff")
        return _iso_ts(data.get("market_settled_ts") if isinstance(data, dict) else None), None
    except Exception as exc:
        return None, f"{type(exc).__name__}: {exc}"


def _kalshi_normalize(raw: dict[str, Any], source_tier: str, cutoff_ts: int | None) -> dict[str, Any] | None:
    ticker = str(NS["field"](raw, "ticker") or "").strip()
    if not ticker:
        return None
    result = str(NS["field"](raw, "result") or "").strip().casefold()
    if result == "yes":
        settlement = 1.0
    elif result == "no":
        settlement = 0.0
    else:
        settlement = _unit_price(NS["field"](
            raw,
            "yes_settlement_value_dollars",
            "settlement_value_dollars",
            "expiration_value",
        ))
    settlement_ts = _iso_ts(NS["field"](
        raw, "settlement_ts", "close_time", "latest_expiration_time", "expiration_time"
    ))
    tier = source_tier
    if cutoff_ts is not None and settlement_ts is not None:
        tier = "historical" if settlement_ts < cutoff_ts else "live"
    return {
        "venue": "Kalshi",
        "market_id": ticker,
        "condition_id": str(NS["field"](raw, "event_ticker") or ""),
        "ticker": ticker,
        "slug": ticker,
        "question": str(NS["field"](raw, "title", "market_title", "yes_sub_title", "subtitle") or ticker)[:500],
        "category": str(NS["field"](raw, "category") or ""),
        "volume": NS["fnum"](NS["field"](raw, "volume_fp", "volume")),
        "yes_token": ticker,
        "terminal_yes_price": settlement,
        "end_ts": settlement_ts,
        "event_ticker": str(NS["field"](raw, "event_ticker") or ""),
        "series_ticker": str(NS["field"](raw, "series_ticker") or ""),
        "data_tier": tier,
        "raw": raw,
    }


def _w4b_kalshi_candidates(cutoff_ts: int | None) -> tuple[list[dict[str, Any]], dict[str, int], list[str]]:
    """One market per W4-B distributional-core event, newest T0 first.

    The W4-B history files were frozen before this retrospective demo. We use
    only semantic family, operational T0, route resolution and candle-count
    availability to choose candidates. Prices/settlements/PnL are not read here.
    """
    stats: dict[str, int] = defaultdict(int)
    errs: list[str] = []
    if not W4B_KALSHI_MARKET.exists() or not W4B_KALSHI_EVENT.exists():
        missing = [str(x.relative_to(ROOT)) for x in (W4B_KALSHI_MARKET, W4B_KALSHI_EVENT) if not x.exists()]
        return [], {"missing_w4b_files": len(missing)}, ["missing:" + ",".join(missing)]

    event_meta: dict[str, dict[str, Any]] = {}
    try:
        with gzip.open(W4B_KALSHI_EVENT, "rt", encoding="utf-8", errors="replace", newline="") as f:
            for r in csv.DictReader(f):
                stats["event_rows_seen"] += 1
                cid = str(r.get("canonical_event_id") or "").strip()
                if not cid:
                    continue
                if str(r.get("distributional_core_flag") or "").upper() != "YES":
                    continue
                t0 = _iso_ts(r.get("operational_t0_ts"))
                if t0 is None:
                    continue
                event_meta[cid] = {
                    "canonical_event_id": cid,
                    "resolved_family": str(r.get("resolved_family") or ""),
                    "history_class": str(r.get("history_class") or ""),
                    "operational_t0_ts": t0,
                }
        stats["distributional_core_events"] = len(event_meta)
    except Exception as exc:
        return [], dict(stats), [f"event_file:{type(exc).__name__}:{exc}"]

    per_event: dict[str, list[dict[str, Any]]] = defaultdict(list)
    try:
        with gzip.open(W4B_KALSHI_MARKET, "rt", encoding="utf-8", errors="replace", newline="") as f:
            for r in csv.DictReader(f):
                stats["market_rows_seen"] += 1
                cid = str(r.get("canonical_event_id") or "").strip()
                if cid not in event_meta:
                    continue
                if str(r.get("http_resolution_status") or "") != "RESOLVED_200_DATA":
                    continue
                candles = int(float(r.get("candlestick_count") or 0))
                if candles <= 0:
                    continue
                ticker = str(r.get("market_ticker") or "").strip()
                if not ticker:
                    continue
                t0 = _iso_ts(r.get("operational_t0_ts")) or event_meta[cid]["operational_t0_ts"]
                old_route = str(r.get("route_used") or "").strip().casefold()
                tier = old_route if old_route in {"historical", "live"} else (
                    "historical" if cutoff_ts is not None and t0 < cutoff_ts else "live"
                )
                per_event[cid].append({
                    "venue": "Kalshi",
                    "market_id": ticker,
                    "condition_id": cid,
                    "ticker": ticker,
                    "slug": ticker,
                    "question": f"{event_meta[cid]['resolved_family']} | {ticker}",
                    "category": event_meta[cid]["resolved_family"],
                    "volume": None,
                    "yes_token": ticker,
                    "terminal_yes_price": None,
                    "end_ts": t0,
                    "history_anchor_ts": t0,
                    "event_ticker": "",
                    "series_ticker": str(r.get("series_ticker") or ""),
                    "data_tier": tier,
                    "source_history_route": old_route,
                    "source_candlestick_count": candles,
                    "history_class": event_meta[cid]["history_class"],
                    "canonical_event_id": cid,
                    "raw": {},
                })
                stats["resolved_data_market_rows"] += 1
    except Exception as exc:
        return [], dict(stats), [f"market_file:{type(exc).__name__}:{exc}"]

    # Choose the best-covered ticker inside each already-qualified event. This is
    # an availability decision only; no price or outcome is read until later.
    reps: list[dict[str, Any]] = []
    for cid, rows in per_event.items():
        rows.sort(key=lambda x: (-int(x.get("source_candlestick_count") or 0), str(x["ticker"])))
        reps.append(rows[0])
    reps.sort(key=lambda x: (-int(x.get("history_anchor_ts") or 0), str(x.get("canonical_event_id") or ""), str(x["ticker"])))
    stats["events_with_resolved_data"] = len(reps)
    selected = reps[:MAX_KALSHI]
    stats["selected_candidates"] = len(selected)
    return selected, dict(stats), errs


def _kalshi_detail(m: dict[str, Any], cutoff_ts: int | None) -> tuple[dict[str, Any], str | None]:
    ticker = str(m["ticker"])
    preferred = str(m.get("data_tier") or "live")
    attempts: list[str] = []
    for tier in [preferred, "historical" if preferred == "live" else "live"]:
        path = (
            f"/historical/markets/{urllib.parse.quote(ticker, safe='')}"
            if tier == "historical"
            else f"/markets/{urllib.parse.quote(ticker, safe='')}"
        )
        try:
            data = NS["http_json"](f"{KALSHI_BASE}{path}")
            raw = data.get("market") if isinstance(data, dict) else None
            n = _kalshi_normalize(raw, tier, cutoff_ts) if isinstance(raw, dict) else None
            if n:
                keep = {
                    k: m.get(k)
                    for k in [
                        "history_anchor_ts", "source_history_route", "source_candlestick_count",
                        "history_class", "canonical_event_id"
                    ]
                }
                merged = {**m, **n, **keep}
                if not merged.get("series_ticker"):
                    merged["series_ticker"] = m.get("series_ticker", "")
                if not merged.get("condition_id"):
                    merged["condition_id"] = m.get("condition_id", "")
                if not merged.get("category"):
                    merged["category"] = m.get("category", "")
                return merged, None
        except urllib.error.HTTPError as exc:
            attempts.append(f"{tier}:HTTP{exc.code}")
        except Exception as exc:
            attempts.append(f"{tier}:{type(exc).__name__}:{exc}")
    return m, ";".join(attempts) or "market_detail_unresolved"


_EVENT_SERIES: dict[str, str] = {}


def _kalshi_series(event_ticker: str) -> tuple[str, str | None]:
    if not event_ticker:
        return "", "missing_event_ticker"
    if event_ticker in _EVENT_SERIES:
        return _EVENT_SERIES[event_ticker], None
    try:
        data = NS["http_json"](f"{KALSHI_BASE}/events/{urllib.parse.quote(event_ticker, safe='')}")
        event = data.get("event") if isinstance(data, dict) else None
        series = str(event.get("series_ticker") or "") if isinstance(event, dict) else ""
        if series:
            _EVENT_SERIES[event_ticker] = series
            return series, None
        return "", "event_missing_series_ticker"
    except Exception as exc:
        return "", f"{type(exc).__name__}: {exc}"


def _parse_kalshi_candles(data: Any, days: int) -> list[dict[str, float]]:
    raw = data.get("candlesticks") if isinstance(data, dict) else None
    pts: list[dict[str, float]] = []
    if not isinstance(raw, list):
        return pts
    for c in raw:
        if not isinstance(c, dict):
            continue
        t = NS["fnum"](c.get("end_period_ts") or c.get("end_ts") or c.get("ts"))
        price_obj = c.get("price") if isinstance(c.get("price"), dict) else {}
        price = _unit_price(price_obj.get("close_dollars") or price_obj.get("close"))
        if price is None:
            vals: list[float] = []
            for key in ("yes_ask", "yes_bid"):
                obj = c.get(key) if isinstance(c.get(key), dict) else {}
                x = _unit_price(obj.get("close_dollars") or obj.get("close"))
                if x is not None:
                    vals.append(x)
            price = (sum(vals) / len(vals)) if vals else None
        if t is not None and price is not None:
            pts.append({"t": float(t), "p": float(price), "days": float(days)})
    return sorted(pts, key=lambda x: x["t"])


def _kalshi_history(m: dict[str, Any]) -> tuple[list[dict[str, float]], str | None, str]:
    ticker = str(m["ticker"])
    preferred = str(m.get("data_tier") or m.get("source_history_route") or "live")
    anchor = int(m.get("history_anchor_ts") or m.get("end_ts") or time.time())
    series = str(m.get("series_ticker") or "")
    series_err = None
    attempts: list[tuple[str, str]] = []
    for use_tier in [preferred, "historical" if preferred == "live" else "live"]:
        if use_tier == "live" and not series:
            series, series_err = _kalshi_series(str(m.get("event_ticker") or ""))
            if not series:
                attempts.append((use_tier, series_err or "missing_series"))
                continue
        for days in [int(NS["LOOKBACK_DAYS"]), 11, 7, 30]:
            start = max(1, anchor - days * 86400)
            params = {"start_ts": start, "end_ts": anchor, "period_interval": 60}
            if use_tier == "historical":
                path = f"/historical/markets/{urllib.parse.quote(ticker, safe='')}/candlesticks"
            else:
                path = f"/series/{urllib.parse.quote(series, safe='')}/markets/{urllib.parse.quote(ticker, safe='')}/candlesticks"
            try:
                data = NS["http_json"](f"{KALSHI_BASE}{path}?{urllib.parse.urlencode(params)}")
                pts = _parse_kalshi_candles(data, days)
                if pts:
                    return pts, None, use_tier
                attempts.append((use_tier, f"no_points:{days}d"))
            except urllib.error.HTTPError as exc:
                attempts.append((use_tier, f"HTTP {exc.code}:{days}d"))
                if exc.code == 404:
                    break
            except Exception as exc:
                attempts.append((use_tier, f"{type(exc).__name__}:{exc}"))
    return [], "; ".join(f"{t}:{e}" for t, e in attempts[-8:]), preferred


def run_kalshi_route_v2():
    cutoff_ts, cutoff_err = _kalshi_cutoff()
    candidates, universe_stats, universe_errs = _w4b_kalshi_candidates(cutoff_ts)

    enriched: list[dict[str, Any]] = []
    detail_errors: list[str] = []
    for m in candidates:
        em, err = _kalshi_detail(m, cutoff_ts)
        if err and len(detail_errors) < 10:
            detail_errors.append(f"{m.get('ticker')}:{err}")
        if em.get("terminal_yes_price") is not None:
            enriched.append(em)

    route_trades: list[dict[str, Any]] = []
    hist_n = 0
    hist_by_tier: dict[str, int] = defaultdict(int)
    err_samples: list[str] = (universe_errs + detail_errors)[:6]
    if cutoff_err:
        err_samples.append(f"cutoff:{cutoff_err}")
    for m in enriched:
        hist, err, used_tier = _kalshi_history(m)
        if hist:
            hist_n += 1
            hist_by_tier[used_tier] += 1
        elif err and len(err_samples) < 14:
            err_samples.append(f"{m.get('ticker')}[{m.get('data_tier')}]: {err}")
        tr = NS["trade_from_history"]("PM_KALSHI_CONTRACT_PNL", m, hist)
        if tr:
            tr["data_tier"] = used_tier
            tr["price_source"] = "kalshi_candlesticks_60m_w4b_universe"
            route_trades.append(tr)

    fun = [
        {"route_id": "PM_KALSHI_CONTRACT_PNL", "stage": "historical_cutoff_resolved", "count": int(cutoff_ts is not None), "notes": str(cutoff_ts or cutoff_err or "")},
        {"route_id": "PM_KALSHI_CONTRACT_PNL", "stage": "w4b_distributional_core_events", "count": int(universe_stats.get("distributional_core_events", 0)), "notes": json.dumps(universe_stats, sort_keys=True)},
        {"route_id": "PM_KALSHI_CONTRACT_PNL", "stage": "candidate_markets", "count": len(candidates), "notes": "one pre-audited resolved-data ticker per W4-B distributional-core event; newest T0 first; no price/outcome/PnL used for selection"},
        {"route_id": "PM_KALSHI_CONTRACT_PNL", "stage": "settlement_detail_resolved", "count": len(enriched), "notes": f"detail_errors={len(detail_errors)}"},
        {"route_id": "PM_KALSHI_CONTRACT_PNL", "stage": "candlestick_history_returned", "count": hist_n, "notes": f"live={hist_by_tier.get('live',0)}; historical={hist_by_tier.get('historical',0)}; interval=60m; " + "; ".join(err_samples[:3])},
        {"route_id": "PM_KALSHI_CONTRACT_PNL", "stage": "trade_rows_materialized", "count": len(route_trades), "notes": "correct tier-specific endpoint; 60m candles anchored to frozen W4-B operational T0"},
        {"route_id": "PM_KALSHI_CONTRACT_PNL", "stage": "executed_threshold_trades", "count": sum(t.get("side") in {"BUY_YES", "BUY_NO"} for t in route_trades), "notes": f"BUY_YES >= {NS['TH_YES']}; BUY_NO <= {NS['TH_NO']}"},
    ]
    summary = NS["summarize_route"]("PM_KALSHI_CONTRACT_PNL", route_trades, len(candidates), hist_n, "; ".join(err_samples[:3]))
    summary.update({
        "market_cutoff_ts": cutoff_ts,
        "history_by_tier": dict(hist_by_tier),
        "w4b_universe_stats": universe_stats,
        "settlement_detail_resolved": len(enriched),
        "candidate_selection": "W4-B distributional-core availability universe; one representative ticker/event; no economic-field ranking",
    })
    return summary, route_trades, fun


# ---------------------------------------------------------------------------
# ForecastEx v2: official daily prices CSV -> Yes/No pair -> settlement.
# ---------------------------------------------------------------------------

def _fx_side(v: Any) -> str:
    s = re.sub(r"[^a-z0-9]+", "", str(v or "").casefold())
    if s in {"yes", "y", "true", "1", "affirmative"} or s.startswith("yes"):
        return "YES"
    if s in {"no", "n", "false", "0", "negative"} or s.startswith("no"):
        return "NO"
    return ""


def _parse_date(v: Any) -> date | None:
    s = str(v or "").strip()
    if not s:
        return None
    for fmt in ("%Y-%m-%d", "%Y%m%d", "%m/%d/%Y", "%m/%d/%y"):
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            pass
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00")).date()
    except Exception:
        return None


def _fx_available_price_dates() -> list[date]:
    path = REGISTRY / "w4b_forecastex_file_manifest_v1.csv.gz"
    out: set[date] = set()
    if not path.exists():
        return []
    with gzip.open(path, "rt", encoding="utf-8", errors="replace", newline="") as f:
        for row in csv.DictReader(f):
            if str(row.get("file_type") or "").casefold() != "prices":
                continue
            if str(row.get("resolved") or "").upper() != "YES":
                continue
            d = _parse_date(row.get("archive_date"))
            if d:
                out.add(d)
    return sorted(out)


def _fx_groups() -> tuple[list[dict[str, Any]], dict[str, int]]:
    path = REGISTRY / "w4b_forecastex_contracts_v1.csv.gz"
    stats: dict[str, int] = defaultdict(int)
    groups: dict[tuple[str, str, str], dict[str, Any]] = {}
    if not path.exists():
        return [], {"missing_contract_census": 1}
    today = datetime.now(timezone.utc).date()
    with gzip.open(path, "rt", encoding="utf-8", errors="replace", newline="") as f:
        for row in csv.DictReader(f):
            stats["rows_seen"] += 1
            if not str(row.get("semantic_status") or "").startswith("ACCEPT") or str(row.get("canonicalization_status") or "") != "PASS":
                continue
            side = _fx_side(row.get("subtype"))
            if not side:
                stats["unknown_subtype"] += 1
                continue
            exp = _parse_date(row.get("expiration_date"))
            if not exp or exp > today:
                stats["not_expired"] += 1
                continue
            contract = str(row.get("event_contract") or "").strip()
            cid = str(row.get("canonical_event_id") or "").strip()
            if not contract or not cid:
                continue
            key = (cid, contract, exp.isoformat())
            g = groups.setdefault(key, {
                "canonical_event_id": cid,
                "event_contract": contract,
                "expiration_date": exp,
                "product_id": str(row.get("product_id") or ""),
                "product_name": str(row.get("product_name") or ""),
                "product_category": str(row.get("product_category") or ""),
                "first_archive_date": _parse_date(row.get("first_archive_date")),
                "last_archive_date": _parse_date(row.get("last_archive_date")),
                "sides": {},
            })
            g["sides"][side] = dict(row)
    complete = [g for g in groups.values() if "YES" in g["sides"] and "NO" in g["sides"]]
    stats["complete_yes_no_pairs"] = len(complete)
    complete.sort(key=lambda g: (g["expiration_date"], g["canonical_event_id"], g["event_contract"]), reverse=True)
    # One representative threshold contract per canonical real-world event, chosen
    # deterministically before reading any price/settlement field.
    selected: list[dict[str, Any]] = []
    seen_events: set[str] = set()
    for g in complete:
        if g["canonical_event_id"] in seen_events:
            continue
        seen_events.add(g["canonical_event_id"])
        selected.append(g)
        if len(selected) >= MAX_FORECASTEX:
            break
    stats["selected_groups"] = len(selected)
    return selected, dict(stats)


def _nearest_dates(avail: list[date], g: dict[str, Any]) -> list[date]:
    if not avail:
        return []
    exp: date = g["expiration_date"]
    first: date = g.get("first_archive_date") or avail[0]
    last: date = g.get("last_archive_date") or avail[-1]
    start = max(first, exp - timedelta(days=int(NS["LOOKBACK_DAYS"])))
    entry_end = min(last, exp - timedelta(days=1))
    picks: set[date] = set()
    if start <= entry_end:
        lo = bisect.bisect_left(avail, start)
        hi = bisect.bisect_right(avail, entry_end)
        window = avail[lo:hi]
        if window:
            picks.update(window[:2])
            if len(window) > 2:
                picks.add(window[len(window) // 2])
                picks.add(window[-1])
    settle_lo = bisect.bisect_left(avail, max(exp, first))
    settle_hi = bisect.bisect_right(avail, last)
    settle = avail[settle_lo:settle_hi]
    if settle:
        picks.update(settle[-3:])
    else:
        # Some contracts disappear from the archive on the expiration date.
        hi = bisect.bisect_right(avail, last)
        if hi:
            picks.add(avail[hi - 1])
    return sorted(picks)


def _fx_fetch_price_date(d: date) -> tuple[date, str | None, str | None]:
    url = f"{FORECASTEX_BASE}/api/download?" + urllib.parse.urlencode({"type": "prices", "date": d.strftime("%Y%m%d")})
    try:
        text = NS["http_text"](url)
        return d, text, None
    except Exception as exc:
        return d, None, f"{type(exc).__name__}: {exc}"


def materialize_forecastex_v2():
    groups, group_stats = _fx_groups()
    available = _fx_available_price_dates()
    route_id = "FORECASTEX_EVENT_CONTRACTS"
    if not groups or not available:
        reason = f"official census inputs insufficient: groups={len(groups)} available_price_dates={len(available)} stats={group_stats}"
        summary = NS["summarize_route"](route_id, [], len(groups), 0, reason)
        summary["status"] = "BLOCKED_FORECASTEX_CENSUS_INPUTS"
        details = {"artifact": "PRESENTATION_DEMO_FORECASTEX_BACKTEST_V2", "status": summary["status"], "reason": reason, "group_stats": group_stats}
        NS["FORECASTEX_OUT"].write_text(json.dumps(details, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        fun = [{"route_id": route_id, "stage": "census_inputs", "count": len(groups), "notes": reason}]
        return summary, [], fun

    wanted_contracts = {g["event_contract"] for g in groups}
    date_plan: dict[str, list[date]] = {g["event_contract"]: _nearest_dates(available, g) for g in groups}
    dates_to_fetch = sorted({d for ds in date_plan.values() for d in ds})
    fetched: dict[date, str] = {}
    fetch_errors: list[str] = []
    with ThreadPoolExecutor(max_workers=max(1, FORECASTEX_WORKERS)) as ex:
        futs = {ex.submit(_fx_fetch_price_date, d): d for d in dates_to_fetch}
        for fut in as_completed(futs):
            d, text, err = fut.result()
            if text is not None:
                fetched[d] = text
            elif err:
                fetch_errors.append(f"{d}:{err}")

    observations: dict[str, dict[date, dict[str, dict[str, Any]]]] = defaultdict(lambda: defaultdict(dict))
    schema_errors: list[str] = []
    for d, text in fetched.items():
        reader = csv.DictReader(io.StringIO(text))
        hdr = set(reader.fieldnames or [])
        required = {"event_contract", "subtype", "expiration_date", "date", "end_price", "settlement_price"}
        if not required.issubset(hdr):
            schema_errors.append(f"{d}:missing={sorted(required-hdr)}")
            continue
        for row in reader:
            contract = str(row.get("event_contract") or "").strip()
            if contract not in wanted_contracts:
                continue
            side = _fx_side(row.get("subtype"))
            if side:
                observations[contract][d][side] = row

    trades: list[dict[str, Any]] = []
    history_returned = 0
    settlement_resolved = 0
    no_entry = 0
    no_settlement = 0
    for g in groups:
        contract = g["event_contract"]
        exp: date = g["expiration_date"]
        obs = observations.get(contract, {})
        entry_dates = sorted(d for d in obs if d < exp and d >= exp - timedelta(days=int(NS["LOOKBACK_DAYS"])))
        entry: tuple[date, float, float | None] | None = None
        for d in entry_dates:
            yes_row = obs[d].get("YES")
            no_row = obs[d].get("NO")
            yp = _unit_price(yes_row.get("end_price") if yes_row else None)
            np = _unit_price(no_row.get("end_price") if no_row else None)
            if yp is not None:
                entry = (d, yp, np)
                break
        if entry is None:
            no_entry += 1
            continue
        history_returned += 1

        yes_settle = None
        no_settle = None
        for d in sorted(obs, reverse=True):
            yr = obs[d].get("YES")
            nr = obs[d].get("NO")
            ys = _unit_price(yr.get("settlement_price") if yr else None)
            ns_ = _unit_price(nr.get("settlement_price") if nr else None)
            if ys in {0.0, 1.0}:
                yes_settle = ys
            if ns_ in {0.0, 1.0}:
                no_settle = ns_
            if yes_settle is not None or no_settle is not None:
                break
        if yes_settle is None and no_settle is not None:
            yes_settle = 1.0 - no_settle
        if no_settle is None and yes_settle is not None:
            no_settle = 1.0 - yes_settle
        if yes_settle is None or no_settle is None:
            no_settlement += 1
            continue
        settlement_resolved += 1

        entry_d, yes_price, no_price = entry
        if yes_price >= NS["TH_YES"]:
            side = "BUY_YES"
            stake = yes_price
            gross = yes_settle - yes_price
        elif yes_price <= NS["TH_NO"] and no_price is not None:
            side = "BUY_NO"
            stake = no_price
            gross = no_settle - no_price
        else:
            side = "ABSTAIN"
            stake = None
            gross = 0.0
        net = gross - (FORECASTEX_FEE if side != "ABSTAIN" else 0.0)
        trades.append({
            "route_id": route_id,
            "venue": "ForecastEx",
            "market_id": contract,
            "condition_id": g["canonical_event_id"],
            "ticker": contract,
            "slug": contract,
            "question": g.get("product_name") or contract,
            "category": g.get("product_category") or "",
            "volume": "",
            "yes_token": f"{contract}:YES",
            "entry_ts": int(datetime.combine(entry_d, datetime.min.time(), tzinfo=timezone.utc).timestamp()),
            "entry_yes_price": yes_price,
            "terminal_yes_price": yes_settle,
            "entry_no_price": "" if no_price is None else no_price,
            "terminal_no_price": no_settle,
            "side": side,
            "gross_pnl_per_contract": gross,
            "net_pnl_per_contract": net,
            "return_on_stake": "" if not stake else net / stake,
            "hit": "" if side == "ABSTAIN" else net > 0,
            "history_points": len(entry_dates),
            "history_window_days": (exp - entry_d).days,
            "data_tier": "official_daily_archive",
            "price_source": "ForecastEx prices CSV",
            "entry_archive_date": entry_d.isoformat(),
        })

    reason_bits = []
    if fetch_errors:
        reason_bits.append(f"fetch_errors={len(fetch_errors)}")
    if schema_errors:
        reason_bits.append(f"schema_errors={len(schema_errors)}")
    summary = NS["summarize_route"](route_id, trades, len(groups), history_returned, "; ".join(reason_bits))
    summary.update({
        "official_archive_dates_planned": len(dates_to_fetch),
        "official_archive_dates_fetched": len(fetched),
        "complete_yes_no_pairs_selected": len(groups),
        "settlement_resolved": settlement_resolved,
        "no_entry": no_entry,
        "no_settlement": no_settlement,
        "fee_per_executed_contract": FORECASTEX_FEE,
        "group_stats": group_stats,
    })
    details = {
        "artifact": "PRESENTATION_DEMO_FORECASTEX_BACKTEST_V2",
        "created_at_utc": NS["now"](),
        "status": summary["status"],
        "selection_policy": "deterministic one complete Yes/No threshold contract per accepted canonical event before reading economic fields",
        "pricing_policy": "actual ForecastEx Yes and No daily close prices; no 1-p complement assumption for entry",
        "settlement_policy": "official settlement_price from the daily prices archive; complementary settlement inferred only if one side is present",
        "fee_per_executed_contract": FORECASTEX_FEE,
        "summary": summary,
        "fetch_error_samples": fetch_errors[:10],
        "schema_error_samples": schema_errors[:10],
        "guardrails": ["presentation_demo_only", "retrospective_non_confirmatory", "does_not_replace_frozen_competition_protocol"],
    }
    NS["FORECASTEX_OUT"].write_text(json.dumps(details, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    fun = [
        {"route_id": route_id, "stage": "accepted_complete_yes_no_pairs", "count": len(groups), "notes": json.dumps(group_stats, sort_keys=True)},
        {"route_id": route_id, "stage": "official_price_archive_dates_fetched", "count": len(fetched), "notes": f"planned={len(dates_to_fetch)}; errors={len(fetch_errors)}"},
        {"route_id": route_id, "stage": "entry_history_returned", "count": history_returned, "notes": f"lookback_days={NS['LOOKBACK_DAYS']}"},
        {"route_id": route_id, "stage": "settlement_resolved", "count": settlement_resolved, "notes": f"missing={no_settlement}"},
        {"route_id": route_id, "stage": "trade_rows_materialized", "count": len(trades), "notes": "uses actual Yes/No prices from official prices CSV"},
        {"route_id": route_id, "stage": "executed_threshold_trades", "count": sum(t.get("side") in {"BUY_YES", "BUY_NO"} for t in trades), "notes": f"BUY_YES >= {NS['TH_YES']}; BUY_NO <= {NS['TH_NO']}; fee=${FORECASTEX_FEE:.2f}"},
    ]
    return summary, trades, fun


NS["run_kalshi_route"] = run_kalshi_route_v2
NS["materialize_forecastex"] = materialize_forecastex_v2


def main() -> int:
    rc = int(NS["main"]())
    summary_path: Path = NS["SUMMARY"]
    if summary_path.exists():
        doc = json.loads(summary_path.read_text(encoding="utf-8"))
        doc["version"] = "v2.1"
        doc["v2_changes"] = {
            "kalshi": "reuses the frozen W4-B distributional-core universe, one resolved-data ticker per canonical event, then resolves current live/historical tier and fetches 60m candles anchored to the frozen operational T0",
            "forecastex": "materializes official daily prices CSV, pairs actual Yes/No contract prices, resolves settlement_price, and executes threshold trades without assuming No price = 1 - Yes price",
        }
        doc.setdefault("parameters", {})["max_forecastex_contracts"] = MAX_FORECASTEX
        doc["parameters"]["forecastex_fee_per_contract"] = FORECASTEX_FEE
        summary_path.write_text(json.dumps(doc, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return rc


if __name__ == "__main__":
    raise SystemExit(main())
